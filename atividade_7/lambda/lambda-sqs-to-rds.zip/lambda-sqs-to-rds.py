import json
import csv
import io
import psycopg2
import boto3
import os

# Inicializar o cliente S3
s3 = boto3.client('s3')

# Configurações do banco de dados
# DB_HOST = os.environ['DB_HOST']
# DB_PORT = os.environ['DB_PORT']
# DB_NAME = os.environ['DB_NAME']
# DB_USER = os.environ['DB_USER']
# DB_PASSWORD = os.environ['DB_PASSWORD']

# Configurações do banco de dados
DB_HOST = 'my-postgresql-db'
DB_PORT = '5432'
DB_NAME = 'mydatabase'
DB_USER = 'postgres'
DB_PASSWORD = 'mysecretpassword'

# Configurações do bucket S3
S3_BUCKET_NAME = 'eedb-011-enriched-data-bucket'

# Função para conectar ao banco de dados PostgreSQL
def connect_to_db():
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    return conn

# Função para enriquecer dados com base em uma consulta ao banco de dados
def enrich_data(row):
    # Conectar ao banco de dados
    conn = connect_to_db()
    cursor = conn.cursor()

    # Exemplo de consulta para enriquecer dados
    # Substitua a consulta conforme a sua necessidade
    sql = "SELECT * FROM tb_employees"
    cursor.execute(sql, (row[0],))
    additional_info = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    # Adicionar informações adicionais à linha
    if additional_info:
        row.append(additional_info[0])
    else:
        row.append('No additional info')

    return row

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    
    enriched_data = []
    
    # Processar cada mensagem na fila
    for record in event['Records']:
        # Mensagem recebida
        message_body = record['body']
        
        # Usar StringIO para tratar a mensagem como um arquivo CSV
        csv_file = io.StringIO(message_body)
        csv_reader = csv.reader(csv_file, delimiter=';')

        # Iterar sobre cada linha do CSV e enriquecer
        for row in csv_reader:
            enriched_row = enrich_data(row)
            enriched_data.append(enriched_row)
    
    # Converter dados enriquecidos de volta para CSV
    output = io.StringIO()
    csv_writer = csv.writer(output, delimiter=';')
    csv_writer.writerows(enriched_data)
    
    # Salvar o CSV enriquecido no S3
    enriched_data_str = output.getvalue()
    s3.put_object(
        Bucket=S3_BUCKET_NAME,
        Key='enriched_data.csv',
        Body=enriched_data_str,
        ContentType='text/csv'
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Processed and enriched data successfully')
    }
